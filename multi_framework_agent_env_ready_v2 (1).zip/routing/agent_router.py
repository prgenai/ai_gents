
from adapters.crew_adapter import CrewAgentWrapper
from adapters.langgraph_adapter import LangGraphAgentWrapper

def route_agent(task_type, config):
    if task_type == "collaboration":
        return CrewAgentWrapper(config)
    elif task_type == "stateful_workflow":
        return LangGraphAgentWrapper(config)
    else:
        raise ValueError("Unsupported task type")
