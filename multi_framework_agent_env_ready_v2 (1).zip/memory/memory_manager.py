
memory_store = {}

def save_memory(key, value):
    memory_store[key] = value

def load_memory(key):
    return memory_store.get(key)
