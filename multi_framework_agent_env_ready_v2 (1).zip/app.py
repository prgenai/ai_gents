
from routing.agent_router import route_agent

if __name__ == "__main__":
    config = {
        "user": "admin",
        "role": "financial_analyst",
        "workflow": "monthly_reporting"
    }

    # Choose between: "collaboration" or "stateful_workflow"
    task_type = "collaboration"

    agent = route_agent(task_type, config)
    result = agent.execute("Summarize key trends in Q1 earnings")
    print(result)
