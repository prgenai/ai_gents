
from base.base_agent import BaseEnterpriseAgent

class LangGraphAgentWrapper(BaseEnterpriseAgent):
    def __init__(self, config):
        super().__init__(config)
        self.workflow_name = config.get("workflow", "default_graph")

    def execute(self, input_data):
        response = f"[LangGraphAgent:{self.workflow_name}] Executing workflow for: {input_data}"
        return response
