
from base.base_agent import BaseEnterpriseAgent
from llm.model_router import query_model

class CrewAgentWrapper(BaseEnterpriseAgent):
    def __init__(self, config):
        super().__init__(config)
        self.role = config.get("role", "analyst")
        self.tools = ["doc_search", "report_generator"]

    def execute(self, input_data):
        prompt = f"As a {self.role}, generate insights from the following request: {input_data}"
        response = query_model("openai", prompt)
        return f"[CrewAgent:{self.role}] Response: {response}"
