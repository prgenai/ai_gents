
class BaseEnterpriseAgent:
    def __init__(self, config):
        self.config = config

    def execute(self, input_data):
        raise NotImplementedError("Must override execute in subclass")
