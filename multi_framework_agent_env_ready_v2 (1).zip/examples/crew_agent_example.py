
from routing.agent_router import route_agent

def run_example():
    config = {
        "user": "bala",
        "role": "financial_analyst",
        "workflow": "q1_summary"
    }
    task_type = "collaboration"
    agent = route_agent(task_type, config)
    result = agent.execute("Analyze the revenue changes and provide a summary for Q1 financial report.")
    print(result)

if __name__ == "__main__":
    run_example()
