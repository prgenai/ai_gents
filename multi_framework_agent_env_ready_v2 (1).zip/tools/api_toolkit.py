
def call_internal_api(data):
    return f"Calling internal API with data: {data}"
